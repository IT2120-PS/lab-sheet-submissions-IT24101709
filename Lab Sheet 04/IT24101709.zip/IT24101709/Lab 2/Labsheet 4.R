##part 1
##Setting Directory

setwd("C:/Users/it24101709/Desktop/IT24101709")
getwd()

##Importing the data set
branch_data <- read.table("Exercise.txt", header = TRUE, sep = ",")

##view the file in a separate window
fix(data)

##Attach the file onto R. so, you can call the variable by their names.
attach(data)

##part 2
##part (a)
##Obtaining box plots
boxplot(X1,main="Box plot for team attendence", outline=TRUE,outpch = 8, horizontal = True)
boxplot(X1,main="Box plot for team salary", outline=TRUE,outpch = 8, horizontal = True)
boxplot(X1,main="Box plot for years", outline=TRUE,outpch = 8, horizontal = True)

##obtaining Histogram
hist(X1, Ylab="Frequency",xlab="Team Attendence",main="Histogram for Team Attendence")
hist(X2, Ylab="Frequency",xlab="Team salary",main="Histogram for Team salary")
hist(X3, Ylab="Frequency",xlab="Years",main="Histogram for Years")

##stem & Leaf plot
stem(X1)
stem(X2)
stem(X3)



##Part (b)
##Mean
mean(X1)
mean(X2)
mean(X3)

##Median
median(X1)
median(X2)
median(X3)

##Standard Deviation
sd(X1)
sd(X2)
sd(X3)

##Part (C)
##Getting five number summary along with mean value
summary(X1)
summary(X2)
summary(X3)

##Getting only five number summary for X1 variable
Quantile(X1)

##Calling first Quartile of X1 using index value
quantile(X1) [2]

##Calling third Quartile of X1 using value
quantile(X1) [4]

##Part (d)
##obtaining Inter Quartile range (IQR) of each variable
IQR(X1)
IQR(X2)
IQR(X3)

##Part 3
get.mode<-function(Y){
  count<-table(X3)
  names(counts[counts == max(counts)])
}

get.mode(X3)

table(X3)

max(counts)

counts == max(counts)

counts [counts == max(counts)]

names(counts[counts == max(counts)])

##part 4
get.outliers<-function(Z){
  q1 <- quantile(Z) [2]
  q3 <- quantile(Z) [4]
  iqr <- q3 - q1
  
  ub <- q3 + 1.5*iqr
  lb <- q1 - 1.5*iqr
  
  print(paste("upper bound = ", ub))
  print(paste("lower Bound = ", lb))
  
}

branch_data <- read.table("Exercise.txt", header = TRUE, sep = ",")

boxplot(branch_data$Sales_X1,
        main = "Boxplot for Sales",
        ylab = "Sales",
        col = "lightblue",
        horizontal = FALSE)

cat("Five-Number Summary for Advertising:\n")
print(summary(branch_data$Advertising_X2))

cat("IQR for Advertising:\n")
print(IQR(branch_data$Advertising_X2))

find_outliers <- function(x) {
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  IQR_val <- Q3 - Q1
  lower_bound <- Q1 - 1.5 * IQR_val
  upper_bound <- Q3 + 1.5 * IQR_val
  x[x < lower_bound | x > upper_bound]
}

outliers_years <- find_outliers(branch_data$Years_X3)
cat("Outliers in Years (Years_X3):\n")
print(outliers_years)


 